from src.ssg.app import *


if __name__ == "__main__":
    run()
